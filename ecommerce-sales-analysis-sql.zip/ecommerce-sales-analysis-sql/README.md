# E-commerce Sales Analysis using SQL

## Project Overview
This beginner-friendly SQL project analyzes a fictional online store's customers, products, orders, and order items. It answers practical business questions using SQL queries.

## Objectives
- Design related tables using primary and foreign keys.
- Insert sample e-commerce data.
- Analyze revenue, product performance, category performance, and customer behavior.
- Practice joins, aggregate functions, `GROUP BY`, `HAVING`, subqueries, and date functions.

## Database
Written for **MySQL 8.0+**.

## Repository Structure
```text
ecommerce-sales-analysis-sql/
├── README.md
└── sql/
    ├── 01_schema_and_sample_data.sql
    └── 02_analysis_queries.sql
```

## How to Run
1. Open MySQL Workbench or another MySQL client.
2. Run `sql/01_schema_and_sample_data.sql` first.
3. Run the queries in `sql/02_analysis_queries.sql` one at a time.
4. Read each question and compare the result with the business insight you can draw.

## Business Questions
1. What is the total revenue from completed orders?
2. Which products generate the most revenue?
3. Which product categories perform best?
4. How much revenue does each month generate?
5. Which customers have placed more than one order?
6. What is the average value of a completed order?
7. Which products have never been ordered?
8. Which orders have a total value above the average completed-order value?

## Concepts Demonstrated
`CREATE TABLE`, primary keys, foreign keys, `INSERT`, `SELECT`, `WHERE`, `JOIN`, `GROUP BY`, `HAVING`, aggregate functions, subqueries, `CASE`, and date functions.

## Notes
- This project uses fictional sample data for learning purposes.
- Revenue is calculated from order items belonging to completed orders only, unless a query explicitly says otherwise.
- This is a small learning project, not a production-ready e-commerce database.

## Future Improvements
- Add more sample records.
- Import a public dataset.
- Add customer segmentation and monthly growth analysis.
- Connect the SQL results to Power BI for a dashboard.
