-- E-commerce Sales Analysis
-- Database: MySQL 8.0+

CREATE DATABASE IF NOT EXISTS ecommerce_sales;
USE ecommerce_sales;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    city VARCHAR(60),
    signup_date DATE
);

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(60),
    price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO customers (customer_id, customer_name, city, signup_date) VALUES
(1, 'Asha Rao', 'Hyderabad', '2025-01-10'),
(2, 'Ravi Kumar', 'Vijayawada', '2025-01-18'),
(3, 'Sara Khan', 'Hyderabad', '2025-02-02'),
(4, 'Arjun Reddy', 'Bengaluru', '2025-02-15'),
(5, 'Meera Das', 'Chennai', '2025-03-05'),
(6, 'Kiran Patel', 'Hyderabad', '2025-03-20');

INSERT INTO products (product_id, product_name, category, price) VALUES
(101, 'Wireless Mouse', 'Accessories', 799.00),
(102, 'Mechanical Keyboard', 'Accessories', 2499.00),
(103, 'USB-C Hub', 'Accessories', 1799.00),
(104, 'Laptop Stand', 'Office', 1299.00),
(105, 'Webcam', 'Electronics', 3299.00),
(106, 'Desk Lamp', 'Office', 999.00),
(107, 'Headphones', 'Electronics', 1999.00),
(108, 'Portable SSD', 'Electronics', 4599.00);

INSERT INTO orders (order_id, customer_id, order_date, status) VALUES
(1001, 1, '2025-04-02', 'Completed'),
(1002, 2, '2025-04-05', 'Completed'),
(1003, 1, '2025-04-19', 'Completed'),
(1004, 3, '2025-05-03', 'Cancelled'),
(1005, 4, '2025-05-12', 'Completed'),
(1006, 5, '2025-05-20', 'Pending'),
(1007, 2, '2025-06-01', 'Completed'),
(1008, 6, '2025-06-11', 'Completed'),
(1009, 3, '2025-06-18', 'Completed');

INSERT INTO order_items (order_item_id, order_id, product_id, quantity, unit_price) VALUES
(1, 1001, 101, 2, 799.00),
(2, 1001, 102, 1, 2499.00),
(3, 1002, 104, 1, 1299.00),
(4, 1002, 107, 1, 1999.00),
(5, 1003, 105, 1, 3299.00),
(6, 1003, 103, 2, 1799.00),
(7, 1004, 102, 1, 2499.00),
(8, 1005, 101, 3, 799.00),
(9, 1005, 106, 2, 999.00),
(10, 1006, 104, 1, 1299.00),
(11, 1007, 107, 2, 1999.00),
(12, 1007, 103, 1, 1799.00),
(13, 1008, 105, 1, 3299.00),
(14, 1008, 106, 1, 999.00),
(15, 1009, 101, 1, 799.00),
(16, 1009, 102, 1, 2499.00),
(17, 1009, 104, 1, 1299.00);
